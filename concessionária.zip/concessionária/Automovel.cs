﻿using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace concessionaria
{
    public class Automovel
    {
        public string Modelo;
        public string Placa;
        public string Cor;
        public int Ano;
        public int Quantidade;
    }


}


