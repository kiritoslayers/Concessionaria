﻿using concessionaria;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace concessionária
{
    public partial class formularioPrincipal : Form
    {
        public static List<Automovel> ListaCompleta = new List<Automovel>();

        public formularioPrincipal()
        {
            InitializeComponent();
                                    
        }

        private void formularioPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void btSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cadastrarVeiculo_Click(object sender, EventArgs e)
        {
            var cad = new CadastrarVeiculo(ListaCompleta);
            cad.ShowDialog();
        }

        private void panelCentro_Paint(object sender, PaintEventArgs e)
        {

        }

        private void venderVeicul_Click(object sender, EventArgs e)
        {

            var vend = new VenderVeiculos(ListaCompleta);
            vend.ShowDialog();           
            
            // EXIBIR A LISTA DE VEÍCULOS
            // SELECIONA OS VEÍCULOS QUE QUER VENDER
            // E VENDE O VEÍCULO
            
            // COLOCAR UM INT NO VEICULO EM ESTOQUE
            // IF ESTOQUE < 10:
            //    MESSAGEM DE ALERTA

        }

        private void buscaVeiculo_Click(object sender, EventArgs e)
        {
            var busca = new ListaVeiculo(ListaCompleta);
            busca.ShowDialog();
        }
    }
}
