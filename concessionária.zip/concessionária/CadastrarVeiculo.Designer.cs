﻿
namespace concessionária
{
    partial class CadastrarVeiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.painelTopo = new System.Windows.Forms.Panel();
            this.lbModelo = new System.Windows.Forms.Label();
            this.lbPlaca = new System.Windows.Forms.Label();
            this.tbModelo = new System.Windows.Forms.TextBox();
            this.tbPlaca = new System.Windows.Forms.TextBox();
            this.lbCor = new System.Windows.Forms.Label();
            this.tbCor = new System.Windows.Forms.TextBox();
            this.lbAno = new System.Windows.Forms.Label();
            this.tbAno = new System.Windows.Forms.TextBox();
            this.btCadastro = new System.Windows.Forms.Button();
            this.btLimpar = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbQuantidade = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // painelTopo
            // 
            this.painelTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(107)))), ((int)(((byte)(68)))));
            this.painelTopo.Dock = System.Windows.Forms.DockStyle.Top;
            this.painelTopo.Location = new System.Drawing.Point(0, 0);
            this.painelTopo.Name = "painelTopo";
            this.painelTopo.Size = new System.Drawing.Size(441, 45);
            this.painelTopo.TabIndex = 2;
            // 
            // lbModelo
            // 
            this.lbModelo.AutoSize = true;
            this.lbModelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.lbModelo.ForeColor = System.Drawing.Color.White;
            this.lbModelo.Location = new System.Drawing.Point(9, 64);
            this.lbModelo.Name = "lbModelo";
            this.lbModelo.Size = new System.Drawing.Size(64, 18);
            this.lbModelo.TabIndex = 0;
            this.lbModelo.Text = "Modelo";
            // 
            // lbPlaca
            // 
            this.lbPlaca.AutoSize = true;
            this.lbPlaca.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.lbPlaca.ForeColor = System.Drawing.Color.White;
            this.lbPlaca.Location = new System.Drawing.Point(6, 141);
            this.lbPlaca.Name = "lbPlaca";
            this.lbPlaca.Size = new System.Drawing.Size(50, 18);
            this.lbPlaca.TabIndex = 1;
            this.lbPlaca.Text = "Placa";
            // 
            // tbModelo
            // 
            this.tbModelo.Location = new System.Drawing.Point(12, 99);
            this.tbModelo.Name = "tbModelo";
            this.tbModelo.Size = new System.Drawing.Size(224, 20);
            this.tbModelo.TabIndex = 0;
            // 
            // tbPlaca
            // 
            this.tbPlaca.Location = new System.Drawing.Point(12, 176);
            this.tbPlaca.Name = "tbPlaca";
            this.tbPlaca.Size = new System.Drawing.Size(224, 20);
            this.tbPlaca.TabIndex = 2;
            // 
            // lbCor
            // 
            this.lbCor.AutoSize = true;
            this.lbCor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.lbCor.ForeColor = System.Drawing.Color.White;
            this.lbCor.Location = new System.Drawing.Point(279, 64);
            this.lbCor.Name = "lbCor";
            this.lbCor.Size = new System.Drawing.Size(36, 18);
            this.lbCor.TabIndex = 6;
            this.lbCor.Text = "Cor";
            // 
            // tbCor
            // 
            this.tbCor.Location = new System.Drawing.Point(285, 99);
            this.tbCor.Name = "tbCor";
            this.tbCor.Size = new System.Drawing.Size(142, 20);
            this.tbCor.TabIndex = 1;
            // 
            // lbAno
            // 
            this.lbAno.AutoSize = true;
            this.lbAno.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.lbAno.ForeColor = System.Drawing.Color.White;
            this.lbAno.Location = new System.Drawing.Point(279, 141);
            this.lbAno.Name = "lbAno";
            this.lbAno.Size = new System.Drawing.Size(37, 18);
            this.lbAno.TabIndex = 8;
            this.lbAno.Text = "Ano";
            // 
            // tbAno
            // 
            this.tbAno.Location = new System.Drawing.Point(285, 176);
            this.tbAno.Name = "tbAno";
            this.tbAno.Size = new System.Drawing.Size(146, 20);
            this.tbAno.TabIndex = 3;
            // 
            // btCadastro
            // 
            this.btCadastro.Location = new System.Drawing.Point(330, 296);
            this.btCadastro.Name = "btCadastro";
            this.btCadastro.Size = new System.Drawing.Size(101, 27);
            this.btCadastro.TabIndex = 9;
            this.btCadastro.Text = "Cadastrar";
            this.btCadastro.UseVisualStyleBackColor = true;
            this.btCadastro.Click += new System.EventHandler(this.btCadastro_Click);
            // 
            // btLimpar
            // 
            this.btLimpar.Location = new System.Drawing.Point(220, 296);
            this.btLimpar.Name = "btLimpar";
            this.btLimpar.Size = new System.Drawing.Size(101, 27);
            this.btLimpar.TabIndex = 10;
            this.btLimpar.Text = "Limpar";
            this.btLimpar.UseVisualStyleBackColor = true;
            this.btLimpar.Click += new System.EventHandler(this.btLimpar_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.Location = new System.Drawing.Point(113, 296);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(101, 27);
            this.btCancelar.TabIndex = 11;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 225);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 18);
            this.label1.TabIndex = 12;
            this.label1.Text = "Quantidade em estoque";
            // 
            // tbQuantidade
            // 
            this.tbQuantidade.Location = new System.Drawing.Point(12, 246);
            this.tbQuantidade.Name = "tbQuantidade";
            this.tbQuantidade.Size = new System.Drawing.Size(202, 20);
            this.tbQuantidade.TabIndex = 13;
            // 
            // CadastrarVeiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(203)))), ((int)(((byte)(165)))));
            this.ClientSize = new System.Drawing.Size(441, 356);
            this.Controls.Add(this.tbQuantidade);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btCancelar);
            this.Controls.Add(this.btLimpar);
            this.Controls.Add(this.btCadastro);
            this.Controls.Add(this.tbAno);
            this.Controls.Add(this.lbAno);
            this.Controls.Add(this.tbCor);
            this.Controls.Add(this.lbCor);
            this.Controls.Add(this.tbPlaca);
            this.Controls.Add(this.lbPlaca);
            this.Controls.Add(this.painelTopo);
            this.Controls.Add(this.lbModelo);
            this.Controls.Add(this.tbModelo);
            this.Name = "CadastrarVeiculo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "CadastrarVeiculo";
            this.Load += new System.EventHandler(this.CadastrarVeiculo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel painelTopo;
        private System.Windows.Forms.Label lbPlaca;
        private System.Windows.Forms.TextBox tbModelo;
        private System.Windows.Forms.Label lbModelo;
        private System.Windows.Forms.TextBox tbPlaca;
        private System.Windows.Forms.Label lbCor;
        private System.Windows.Forms.TextBox tbCor;
        private System.Windows.Forms.Label lbAno;
        private System.Windows.Forms.TextBox tbAno;
        private System.Windows.Forms.Button btCadastro;
        private System.Windows.Forms.Button btLimpar;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbQuantidade;
    }
}