﻿
namespace concessionária
{
    partial class formularioPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.painelTopo = new System.Windows.Forms.Panel();
            this.painelVertical = new System.Windows.Forms.Panel();
            this.btSair = new System.Windows.Forms.Button();
            this.venderVeicul = new System.Windows.Forms.Button();
            this.buscaVeiculo = new System.Windows.Forms.Button();
            this.cadastrarVeiculo = new System.Windows.Forms.Button();
            this.panelCentro = new System.Windows.Forms.Panel();
            this.painelVertical.SuspendLayout();
            this.SuspendLayout();
            // 
            // painelTopo
            // 
            this.painelTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(107)))), ((int)(((byte)(68)))));
            this.painelTopo.Dock = System.Windows.Forms.DockStyle.Top;
            this.painelTopo.Location = new System.Drawing.Point(0, 0);
            this.painelTopo.Name = "painelTopo";
            this.painelTopo.Size = new System.Drawing.Size(631, 45);
            this.painelTopo.TabIndex = 0;
            // 
            // painelVertical
            // 
            this.painelVertical.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(203)))), ((int)(((byte)(165)))));
            this.painelVertical.Controls.Add(this.btSair);
            this.painelVertical.Controls.Add(this.venderVeicul);
            this.painelVertical.Controls.Add(this.buscaVeiculo);
            this.painelVertical.Controls.Add(this.cadastrarVeiculo);
            this.painelVertical.Dock = System.Windows.Forms.DockStyle.Left;
            this.painelVertical.Location = new System.Drawing.Point(0, 45);
            this.painelVertical.Name = "painelVertical";
            this.painelVertical.Size = new System.Drawing.Size(233, 225);
            this.painelVertical.TabIndex = 1;
            // 
            // btSair
            // 
            this.btSair.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btSair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btSair.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSair.Location = new System.Drawing.Point(0, 142);
            this.btSair.Name = "btSair";
            this.btSair.Size = new System.Drawing.Size(233, 31);
            this.btSair.TabIndex = 4;
            this.btSair.Text = "Sair";
            this.btSair.UseVisualStyleBackColor = true;
            this.btSair.Click += new System.EventHandler(this.btSair_Click);
            // 
            // venderVeicul
            // 
            this.venderVeicul.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.venderVeicul.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.venderVeicul.Location = new System.Drawing.Point(0, 105);
            this.venderVeicul.Name = "venderVeicul";
            this.venderVeicul.Size = new System.Drawing.Size(233, 31);
            this.venderVeicul.TabIndex = 3;
            this.venderVeicul.Text = "Vender Veículo";
            this.venderVeicul.UseVisualStyleBackColor = true;
            this.venderVeicul.Click += new System.EventHandler(this.venderVeicul_Click);
            // 
            // buscaVeiculo
            // 
            this.buscaVeiculo.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buscaVeiculo.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buscaVeiculo.Location = new System.Drawing.Point(0, 68);
            this.buscaVeiculo.Name = "buscaVeiculo";
            this.buscaVeiculo.Size = new System.Drawing.Size(233, 31);
            this.buscaVeiculo.TabIndex = 3;
            this.buscaVeiculo.Text = "Buscar Veículo";
            this.buscaVeiculo.UseVisualStyleBackColor = true;
            this.buscaVeiculo.Click += new System.EventHandler(this.buscaVeiculo_Click);
            // 
            // cadastrarVeiculo
            // 
            this.cadastrarVeiculo.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cadastrarVeiculo.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cadastrarVeiculo.Location = new System.Drawing.Point(0, 31);
            this.cadastrarVeiculo.Name = "cadastrarVeiculo";
            this.cadastrarVeiculo.Size = new System.Drawing.Size(233, 31);
            this.cadastrarVeiculo.TabIndex = 2;
            this.cadastrarVeiculo.Text = "Cadastrar Veículos";
            this.cadastrarVeiculo.UseVisualStyleBackColor = true;
            this.cadastrarVeiculo.Click += new System.EventHandler(this.cadastrarVeiculo_Click);
            // 
            // panelCentro
            // 
            this.panelCentro.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panelCentro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCentro.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panelCentro.Location = new System.Drawing.Point(233, 45);
            this.panelCentro.Name = "panelCentro";
            this.panelCentro.Size = new System.Drawing.Size(398, 225);
            this.panelCentro.TabIndex = 2;
            this.panelCentro.Paint += new System.Windows.Forms.PaintEventHandler(this.panelCentro_Paint);
            // 
            // formularioPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(631, 270);
            this.Controls.Add(this.panelCentro);
            this.Controls.Add(this.painelVertical);
            this.Controls.Add(this.painelTopo);
            this.Name = "formularioPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.formularioPrincipal_Load);
            this.painelVertical.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel painelTopo;
        private System.Windows.Forms.Panel painelVertical;
        private System.Windows.Forms.Button cadastrarVeiculo;
        private System.Windows.Forms.Button buscaVeiculo;
        private System.Windows.Forms.Button venderVeicul;
        private System.Windows.Forms.Button btSair;
        private System.Windows.Forms.Panel panelCentro;
    }
}

