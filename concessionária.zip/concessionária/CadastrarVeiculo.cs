﻿using concessionaria;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace concessionária
{
    public partial class CadastrarVeiculo : Form
    {                   
        public CadastrarVeiculo(List<Automovel> ListaCompleta)
        {
            InitializeComponent();
            ListaCompletaNova = ListaCompleta;
        }

        public static List<Automovel> ListaCompletaNova;
        private void CadastrarVeiculo_Load(object sender, EventArgs e)
        {
            
        }

        private void lbAno_Click(object sender, EventArgs e)
        {

        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            tbModelo.Clear();
            tbCor.Clear();
            tbPlaca.Clear();
            tbAno.Clear();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btCadastro_Click(object sender, EventArgs e)
        {
            var veiculo = new Automovel();
            veiculo.Modelo = tbModelo.Text;
            veiculo.Cor = tbCor.Text;
            veiculo.Placa = tbPlaca.Text;
            veiculo.Ano = int.Parse(tbAno.Text.ToString());
            veiculo.Quantidade = int.Parse(tbQuantidade.Text.ToString());

            ListaCompletaNova.Add(veiculo);
            
            tbModelo.Clear();
            tbCor.Clear();
            tbPlaca.Clear();
            tbAno.Clear();
            tbQuantidade.Clear();
        }
    }
}
