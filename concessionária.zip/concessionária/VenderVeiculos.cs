﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using concessionaria;
using System.Windows.Forms;

namespace concessionária
{
    public partial class VenderVeiculos : Form
    {
        public VenderVeiculos(List<Automovel> ListaCompleta)
        {
            InitializeComponent();
            ListaCompletaNova = ListaCompleta;
        }



        List<Automovel> ListaCompletaNova = new List<Automovel>();
        private void button2_Click(object sender, EventArgs e)
        {
            foreach (var item in ListaCompletaNova)
            {
                string[] lista = { item.Modelo, item.Cor, item.Placa, item.Ano.ToString(), item.Quantidade.ToString() };
                ListViewItem verItem = new ListViewItem(lista);
                listaVer.Items.Add(verItem);
            }
        }

        public void Atualizar()
        {
            foreach (var item in ListaCompletaNova)
            {
                string[] lista = { item.Modelo, item.Cor, item.Placa, item.Ano.ToString(), item.Quantidade.ToString()};
                ListViewItem verItem = new ListViewItem(lista);
                listaVer.Items.Add(verItem);
            }

        }


        private void button1_Click(object sender, EventArgs e)
        {
            Automovel veic = null;
            

            foreach (ListViewItem item in listaVer.SelectedItems)
            {
                foreach (var automovel in ListaCompletaNova)
                {
                    if (automovel.Modelo == item.Text)
                    {
                        veic = automovel;
                        veic.Quantidade -= 1;
                    }
                }

                if (veic.Quantidade == 0)
                {
                    ListaCompletaNova.Remove(veic);
                }

                if (veic.Quantidade < 10)
                {
                    MessageBox.Show("Atenção mercadoria com pouco estoque! " + veic.Quantidade.ToString());
                }

                }


            //MessageBox.Show("Veiculo vendido");

            listaVer.Items.Clear();


            Atualizar();

        }
    }
}
