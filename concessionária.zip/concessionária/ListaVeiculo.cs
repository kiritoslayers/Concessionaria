﻿using System;
using concessionaria;
using System.Windows.Forms;
using System.Collections.Generic;

namespace concessionária
{
    public partial class ListaVeiculo : Form
    {
        public ListaVeiculo(List<Automovel> listaCompleta)
        {
            InitializeComponent();
            ListaCompletaNova = listaCompleta;
        }

        public List<Automovel> ListaCompletaNova;

        private void gbVeiculos_Enter(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            foreach (var item in ListaCompletaNova)
            {
                string[] row = { item.Modelo, item.Cor, item.Placa, item.Ano.ToString(), item.Quantidade.ToString() };
                var listViewItem = new ListViewItem(row);
                listaVer.Items.Add(listViewItem);
            }
        }

        private void listaVer_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
